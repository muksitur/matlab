function [ output_args ] = Untitled( img )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

[R,C] = size(img);
disp(R);
disp(C);

arrimg = zeros(1,R*C);

tamp = img;

Red = img(:,:,1);
Gre = img(:,:,2);
Blu = img(:,:,3);

i = 1;
for r = 1:R
    for c = ((C/3)*2)+1:C
        arrimg(1,i) = Blu(r,c-((C/3)*2));
        i = i + 1;
    end
end

for r = 1:R
    for c = ((C/3)*2)+1:C
        Blu(r,c-((C/3)*2)) = 0;
    end
end

tamp(:,:,3) = Blu;

figure;
imshow(img); title('original');

figure;
imshow(tamp); title('blue tampered');
end

